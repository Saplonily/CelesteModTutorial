namespace Celeste.Mod.CelesteModTutorial;

public sealed class CelesteModTutorialSession : EverestModuleSession
{
}