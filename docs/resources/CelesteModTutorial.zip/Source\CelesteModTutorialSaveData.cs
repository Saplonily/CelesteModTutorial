namespace Celeste.Mod.CelesteModTutorial;

public sealed class CelesteModTutorialSaveData : EverestModuleSaveData
{
}