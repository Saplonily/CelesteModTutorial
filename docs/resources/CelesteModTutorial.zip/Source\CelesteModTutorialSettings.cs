namespace Celeste.Mod.CelesteModTutorial;

public sealed class CelesteModTutorialSettings : EverestModuleSettings
{
}