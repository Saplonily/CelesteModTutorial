namespace Celeste.Mod.CelesteModTutorial
{
    public class CelesteModTutorialSaveData : EverestModuleSaveData
    {
    }
}