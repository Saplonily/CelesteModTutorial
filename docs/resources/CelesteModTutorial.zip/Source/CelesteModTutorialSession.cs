namespace Celeste.Mod.CelesteModTutorial
{
    public class CelesteModTutorialSession : EverestModuleSession
    {
    }
}