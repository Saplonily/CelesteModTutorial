namespace Celeste.Mod.CelesteModTutorial
{
    public class CelesteModTutorialSettings : EverestModuleSettings
    {
    }
}