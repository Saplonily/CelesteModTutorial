local entity = {}

entity.name = "MyCelesteMod/SampleTrigger"
entity.placements = {
    name = "SampleTrigger",
    data = {
        width = 16,
        height = 16,
    }
}

return entity