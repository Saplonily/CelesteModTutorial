local entity = {}

entity.name = "MyCelesteMod/SampleEntity"
entity.placements = {
    name = "SampleEntity",
    data = {
        width = 16,
        height = 16,
    }
}

return entity